import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class Dictionary{
    String dictionary;
    /**
     * @throws IOException
     * 
     */
    public Dictionary() throws IOException{
        Path filePath = Path.of("C:/Users/24harrisk/Documents/Anagrams/corncob_lowercase.txt");

        dictionary = Files.readString(filePath);
        
    }
}