import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class EvilHangman{
    Dictionary dictionary;
    String words = "";
    String lettersGuessed = "";
    String word = "chad";
    Scanner console = new Scanner(System.in);
    int guesses = 7;
    boolean won=false;
    String guess;
    String progress = "#######";
    String incorrect = "";
    public EvilHangman(){
       try {
        dictionary = new Dictionary();
        words = dictionary.dictionary;

    } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
        
    }

public void sortIntoBins(){

}
public void playGame(){
    while(guesses>7 && !won){
        System.out.println("Guess");
        guess =console.nextLine();
        ArrayList<Integer> locations = getLocation();
        if(getLocation().size() > 0){
                for(int i = 0; i < getLocation().size(); i++){
                    
                }
        }
    }
}
public ArrayList<Integer> getLocation(){
    ArrayList<Integer> location = new ArrayList<Integer>();
    for(int i =0; i<word.length(); i++){
        if(word.charAt(i) == guess.charAt(0)){
            location.add(i);
        }
    }
    return location;
}

    public static void main(String[] args) {
     
    }
}