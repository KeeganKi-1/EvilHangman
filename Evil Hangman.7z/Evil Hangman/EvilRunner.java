import java.io.IOException;

public class EvilRunner {
    public static void main(String[] args) throws IOException {
        String hi = "hi";
     System.out.println(hi.substring(0,0));
    }
}
