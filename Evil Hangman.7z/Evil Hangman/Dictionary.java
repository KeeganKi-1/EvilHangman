import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Scanner;

public class Dictionary{
   ArrayList<String> dictionary = new ArrayList<String>();
    /**
     * @throws IOException
     * 
     */
    public Dictionary() throws IOException{
        Scanner file = new Scanner(new File("corncob_lowercase.txt"));
        while(file.hasNextLine())
    dictionary.add(file.nextLine());

    file.close();
        
    }
}