import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Map.Entry;

public class EvilHangman {
    Dictionary dictionary = new Dictionary();
     ArrayList<String> possibleWords = dictionary.dictionary;
     String lettersGuessed = "";
    
    Scanner console = new Scanner(System.in);
     static BufferedReader reader = new BufferedReader(
            new InputStreamReader(System.in));
     int guesses = 25;
     boolean won = false;
     String guess;
     String progress = "######";
    
public EvilHangman() throws IOException{

for(int i = 0; i < possibleWords.size(); i++){
    if(possibleWords.get(i).length()!=6){

    possibleWords.remove(i);
    i--;
    }

}


}

    public ArrayList<Integer> sortIntoBins() throws IOException {
        HashMap<ArrayList<Integer>,Integer> bins = new HashMap<>();
        bins.put(new ArrayList<Integer>(), 0);
        ArrayList<Integer> indexes = new ArrayList<Integer>();
        for(int i =0; i<possibleWords.size(); i++ ){
           for(int j =0; j<possibleWords.get(i).length(); j++){
            if(guess.charAt(0) == possibleWords.get(i).charAt(j))
            indexes.add(j);
            
           }
           if(bins.containsKey(indexes))
           bins.replace(new ArrayList<Integer>(indexes), bins.get(indexes)+1);
            else
            bins.put(new ArrayList<Integer>(indexes), 1);
            indexes.clear();
            }
            
        
            System.out.println(bins);
            System.out.println(possibleWords.size());
        int maxValueInMap = (Collections.max(bins.values()));
          
        for (Entry<ArrayList<Integer>, Integer> entry : bins.entrySet()) {
           
            if (entry.getValue() == maxValueInMap){
                for(int i =0; i<possibleWords.size(); i++){
                    if(entry.getKey().size() == 0){
                        if(possibleWords.get(i).contains(guess)){
                            possibleWords.remove(i);
                            i--;
                        }
                    }
                    else{
                        
                        for(int j =0; j<entry.getKey().size(); j++){
                            if(guess.charAt(0) != possibleWords.get(i).charAt(entry.getKey().get(j))){
                                possibleWords.remove(i);
                                i--;
                                break;
                            }
                        }
                        
                    }
                }
                
                return entry.getKey();
            }
        }

        return null;
    }
 

    public  void playGame() throws IOException {
        
            System.out.println("Guess:");
            
            ArrayList<Integer> locations = sortIntoBins();
            for (int i = 0; i < locations.size(); i++) {
               progress =  progress.substring(0, locations.get(i)) +guess+progress.substring(locations.get(i)+1);
            }
            lettersGuessed+=guess;
            System.out.println("Progress: "+ progress);
            System.out.println("Guesses Left: "+guesses);
            System.out.println("Guessed: "+ lettersGuessed);
            guesses--;
            
            if(possibleWords.size() == 1)
            won = true;
        
    }


    public static void main(String[] args) throws IOException {
        EvilHangman hangManRunner = new EvilHangman();

        System.out.println("Guess:");
        while (hangManRunner.guesses >= 0 && !hangManRunner.won) {
        hangManRunner.guess = reader.readLine().toLowerCase();
        hangManRunner.playGame();
    }

if(hangManRunner.won){
    System.out.println("GJ!");
    System.out.println("Progress: "+ hangManRunner.progress);
}
else{
    System.out.println("Lost!");

}
}
}